package com.applications.tcb.hw2;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.applications.tcb.hw2.Database.UserDatabase;
import com.applications.tcb.hw2.Database.UserEntity;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import com.applications.tcb.hw2.API.Results;
import com.applications.tcb.hw2.API.User;
import com.applications.tcb.hw2.API.UserAPIClient;
import com.applications.tcb.hw2.API.UserService;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MainActivity extends AppCompatActivity {

    public UserDatabase db;
    private Results results;
    private Context context;
    private String firstName;
    private String lastName;
    private int age;
    private String email;
    private String city;
    private String county;
    private String uuid;
    private String error = "error";
    private boolean isCorrect;
    private User user;
    private String imageURL;

    Button btnViewCol;
    Button btnNextUser;
    Button btnAddToCol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = UserDatabase.getInstance(this);

        context = this;
        TextView textViewFirstName = findViewById(R.id.textFirstname);
        TextView textViewLastName = findViewById(R.id.textLastname);
        TextView textViewAge = findViewById(R.id.textAge);
        TextView textViewEmail = findViewById(R.id.textEmail);
        TextView textViewCity = findViewById(R.id.textCity);
        TextView textViewCountry = findViewById(R.id.textCountry);
        ImageView imageView = findViewById(R.id.imageViewPhoto);

        btnViewCol = findViewById(R.id.btnViewCollection);
        btnNextUser = findViewById(R.id.btnNextUser);
        btnAddToCol = findViewById(R.id.btnAddToCollection);

        btnViewCol.setEnabled(false);
        btnNextUser.setEnabled(false);
        btnAddToCol.setEnabled(false);

        LoadContent(textViewFirstName, textViewLastName, textViewAge, textViewEmail, textViewCity, textViewCountry, imageView);

        btnNextUser.setOnClickListener(v -> {
            btnViewCol.setEnabled(false);
            btnNextUser.setEnabled(false);
            btnAddToCol.setEnabled(false);
            LoadContent(textViewFirstName, textViewLastName, textViewAge, textViewEmail, textViewCity, textViewCountry, imageView);
        });

        btnAddToCol.setOnClickListener(v -> {
            if (isCorrect)
                AddUser(user);
            else
                Toast.makeText(this, "Cannot add user to collection!", Toast.LENGTH_LONG).show();
        });

        btnViewCol.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, UserlistActivity.class);
            startActivity(intent);
        });
    }

    public void LoadContent(TextView textFirstName, TextView textLastName, TextView textAge, TextView textEmail, TextView textCity, TextView textCountry, ImageView imagePicture) {

        Retrofit retrofit = UserAPIClient.getClient();
        UserService service = retrofit.create(UserService.class);
        Call<Results> callAsync = service.getUsers();

        callAsync.enqueue(new Callback<Results>() {
            @Override
            public void onResponse(@NonNull Call<Results> call, @NonNull Response<Results> response) {
                isCorrect = true;
                results = response.body();
                assert results != null;
                ArrayList<User> resultsList = results.getResults();
                user = resultsList.get(0);
                firstName = user.name.getFirst();
                lastName = user.name.getLast();
                age = user.dob.age;
                email = user.email;
                city = user.location.city;
                county = user.location.country;
                imageURL = user.picture.large;
                uuid = user.login.uuid;

                btnViewCol.setEnabled(true);
                btnNextUser.setEnabled(true);
                btnAddToCol.setEnabled(true);

                textFirstName.setText(firstName);
                textLastName.setText(lastName);
                textAge.setText("Age: " + Integer.toString(age));
                textEmail.setText("Email: " + email);
                textCity.setText("City: " + city);
                textCountry.setText("Country: " + county);
                Glide.with(context)
                        .load(imageURL)
                        .into(imagePicture);
            }

            @Override
            public void onFailure(@NonNull Call<Results> call, @NonNull Throwable throwable) {
                isCorrect = false;
                btnViewCol.setEnabled(true);
                btnNextUser.setEnabled(true);
                btnAddToCol.setEnabled(true);

                textFirstName.setText(error);
                textLastName.setText(error);
                textAge.setText("Age: " + error);
                textEmail.setText("Email: " + error);
                textCity.setText("City: " + error);
                textCountry.setText("Country: " + error);
                Glide.with(context)
                        .load(R.drawable.error_icon_25264)
                        .into(imagePicture);
            }
        });
    }
    private void AddUser(User user) {
        UserEntity userEntity = new UserEntity();
        userEntity.firstName = user.name.getFirst();
        userEntity.lastName = user.name.getLast();
        userEntity.city = user.location.city;
        userEntity.country = user.location.country;
        userEntity.imageUrl = user.picture.large;
        userEntity.uuid = user.login.uuid;
        db.userDao().insertUser(userEntity);
    }
}