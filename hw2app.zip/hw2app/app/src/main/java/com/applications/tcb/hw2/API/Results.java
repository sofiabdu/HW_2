package com.applications.tcb.hw2.API;

import java.util.ArrayList;

public class Results{
    public ArrayList<User> getResults() {
        return results;
    }

    public ArrayList<User> results;
}