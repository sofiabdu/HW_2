package com.applications.tcb.hw2.API;

public class Picture {
    public String large;
}
