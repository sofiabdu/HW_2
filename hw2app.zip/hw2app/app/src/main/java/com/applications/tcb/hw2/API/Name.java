package com.applications.tcb.hw2.API;

public class Name {

    public String getFirst() {
        return first;
    }

    public String getLast() {
        return last;
    }

    public String first;
    public String last;
}
