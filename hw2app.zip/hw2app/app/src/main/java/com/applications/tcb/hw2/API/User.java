package com.applications.tcb.hw2.API;

public class User {
    public Dob dob;
    public Name name;
    public Location location;
    public Login login;
    public Picture picture;
    public String email;
}
