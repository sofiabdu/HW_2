package com.applications.tcb.hw2.API;

public class Location{
    public String city;
    public String country;

}