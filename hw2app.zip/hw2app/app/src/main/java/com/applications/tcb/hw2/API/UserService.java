package com.applications.tcb.hw2.API;

import retrofit2.Call;
import retrofit2.http.GET;

public interface UserService {
    @GET("/api")
    public Call<Results> getUsers();
}