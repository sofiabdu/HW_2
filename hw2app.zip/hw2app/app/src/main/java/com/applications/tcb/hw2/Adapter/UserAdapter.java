package com.applications.tcb.hw2.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

import com.applications.tcb.hw2.R;
import com.applications.tcb.hw2.Database.UserEntity;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {

    private List<UserEntity> personList;

    public UserAdapter(List<UserEntity> personList) {
        this.personList = personList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.user_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        UserEntity person = personList.get(position);
        holder.firstNameTextView.setText(person.firstName);
        holder.lastNameTextView.setText(person.lastName);
        holder.countryTextView.setText(person.country);
        holder.cityTextView.setText(person.city);

        Glide.with(holder.imageView.getContext())
                .load(person.imageUrl)
                .placeholder(R.drawable.identity) // Placeholder image
                .into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return personList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;
        public TextView firstNameTextView;
        public TextView lastNameTextView;
        public TextView countryTextView;
        public TextView cityTextView;

        public ViewHolder(View view) {
            super(view);
            imageView = view.findViewById(R.id.imageView);
            firstNameTextView = view.findViewById(R.id.textViewFirstName);
            lastNameTextView = view.findViewById(R.id.textViewLastName);
            countryTextView = view.findViewById(R.id.textViewCountry);
            cityTextView = view.findViewById(R.id.textViewCity);
        }
    }
}
