package com.applications.tcb.hw2.API;

public class Dob {
    public int age;
}

