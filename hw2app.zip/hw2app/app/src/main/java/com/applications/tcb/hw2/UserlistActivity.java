package com.applications.tcb.hw2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.applications.tcb.hw2.Adapter.UserAdapter;
import com.applications.tcb.hw2.Database.UserDatabase;
import com.applications.tcb.hw2.Database.UserEntity;
import java.util.List;

public class UserlistActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private UserAdapter adapter;
    private UserDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlist);
        db = UserDatabase.getInstance(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<UserEntity> users = db.userDao().getAll();
        adapter = new UserAdapter(users);
        recyclerView.setAdapter(adapter);
    }
}